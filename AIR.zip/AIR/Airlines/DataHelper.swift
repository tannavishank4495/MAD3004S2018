//
//  DataHelper.swift
//  Airlines
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


class DataHelper{
    
    var AirlinesList = [String : Airlines]()
    
    
    init(){
        self.loadAirlinesData()
        
    }
    
    
    
    func loadAirlinesData(){
        
        AirlinesList = [:]
        
        
        let AirCanada = Airlines(AirlinesID: "A100", AirlinesDescription: "One of the best indian airline" , AirlinesType : "International" , category: AirlinesCategory.AirlinesID)
        
        AirlinesList[AirCanada.AirlinesID!] = AirCanada
        
        let Lufthansa = Airlines(AirlinesID: "B101", AirlinesDescription: "First Canadian airline" , AirlinesType: "International" ,category: AirlinesCategory.AirlinesID)
        
        AirlinesList[Lufthansa.AirlinesID!] = Lufthansa
        
        let AirIndia = Airlines(AirlinesID: "C102", AirlinesDescription: "Most preffeble airline" , AirlinesType: "International" , category: AirlinesCategory.AirlinesID )
        
        AirlinesList[AirIndia.AirlinesID!] = AirIndia
        
        let Westjet = Airlines(AirlinesID: "D103", AirlinesDescription: "Common airline" , AirlinesType: "International", category: AirlinesCategory.AirlinesID )
        
        AirlinesList[Westjet.AirlinesID!] = Westjet
        
    }
    
    func displayAirlines(){
        
        for (_, value) in self.AirlinesList.sorted(by: { $0.key < $1.key} ){
            
            print(value.displayData())
            
        }
        
    }
    
    
}

