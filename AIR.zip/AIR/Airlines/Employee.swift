//
//  Employee.swift
//  Airlines
//
//  Created by MacStudent on 23/07/18.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Employee{
    private var EmployeeID : String?
    private var EmployeeName : String?
    private var EmployeeEmail : String?
    private var EmployeeMobile : String?
    private var EmployeeAddress : String?
    private var EmployeeDesignation : String?
    private var EmployeeSinNumber : String?

    
    var employeeName  : String?{
        
        get{
            
            return self.EmployeeName
            
        }
        
        set{
            
            self.employeeName = newValue
            
        }
        
    }
    
    
    
    var employeeEmail : String?{
        
        get{
            
            return self.EmployeeEmail
            
        }
        
        set{
            
            self.EmployeeEmail  = newValue
            
        }
        
    }
    
    
    
    var employeeMobile : String?{
        
        get{
            
            return self.EmployeeMobile
            
        }
        
        set{
            
            self.EmployeeMobile = newValue
            
        }
        
    }
    
    
    
    var employeeAddress : String?{
        
        get{
            
            return self.EmployeeAddress
            
        }
        
        set{
            
            self.EmployeeAddress = newValue
            
        }
        
    }
    
    
    
    var employeeDesignation : String?{
        
        get{
            
            return self.EmployeeDesignation
            
        }
        
        set{
            
            self.EmployeeDesignation = newValue
            
        }
        
    }
    
    
    
    var employeeSinnumber : String?{
        
        get{
            
            return self.EmployeeSinNumber
            
        }
        
        set{
            
            self.EmployeeSinNumber = newValue
            
        }
        
    }
    
    init(){
        self.EmployeeID = ""
        self.EmployeeName = ""
        self.EmployeeEmail = ""
        self.EmployeeMobile = ""
        self.EmployeeAddress = ""
        self.EmployeeDesignation = ""
        self.EmployeeSinNumber = ""
    }

    init(EmployeeID: String, EmployeeName: String, EmployeeEmail: String,EmployeeMobile: String, EmployeeAddress: String, EmployeeDesignation: String, EmployeeSinNumber: String){
        self.EmployeeID = EmployeeID
        self.EmployeeName = EmployeeName
        self.EmployeeEmail = EmployeeEmail
        self.EmployeeMobile = EmployeeMobile
        self.EmployeeAddress = EmployeeAddress
        self.EmployeeDesignation = EmployeeDesignation
        self.EmployeeSinNumber = EmployeeSinNumber
    }
    
    
    
    
    func addEmployee(){
        
        print("Enter Employee Id : ")
        
        self.EmployeeID = readLine()!
        
        print("Enter Employee Name : ")
        
        self.EmployeeName = readLine()!
        
        print("Enter Employee Email : ")
        
        self.EmployeeEmail = readLine()!
        
        print("Enter Employee Mobile : ")
        
        self.EmployeeMobile = readLine()!
        
        print("Enter Employee Address : ")
        
        self.EmployeeAddress = readLine()!
        
        print("Enter Employee Designation : ")
        
        self.EmployeeDesignation = readLine()!
        
        print("Enter Employee SIN Number : ")
        
        self.EmployeeSinNumber = readLine()!
        
    }
    
    
    func displayData() -> String{
        
        var returnData = ""
        
        
        
        if self.EmployeeID != nil{
            
            returnData += "Employee ID : \(String(describing: self.EmployeeID ))"
            
        }
        
        if self.EmployeeName != nil{
            
            returnData += "\n Employee Name : " + self.EmployeeName!
            
        }
        
        if self.EmployeeEmail != nil{
            
            returnData += "\n Employee Email : " + self.EmployeeEmail!
            
        }
        
        if self.EmployeeMobile != nil{
            
            returnData += "\n Employee Mobile : " + self.EmployeeMobile!
            
        }
        
        if self.EmployeeAddress != nil{
            
            returnData += "\n Employee Address : " + self.EmployeeAddress!
            
        }
        
        if self.EmployeeDesignation != nil{
            
            returnData += "\n Employee Designation : " + self.EmployeeDesignation!
            
        }
        
        if self.EmployeeSinNumber != nil{
            
            returnData += "\n Employee SINnumber : " + self.EmployeeSinNumber!
            
        }
        
        return returnData
        
    }
}




