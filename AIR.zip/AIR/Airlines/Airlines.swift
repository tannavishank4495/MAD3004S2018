//
//  Airlines.swift
//  Airlines
//
//  Created by MacStudent on 19/07/18.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Airlines : IDisplay{
     var AirlinesID : String?
    private var AirlinesDescription : String?
    private var AirlinesType : String?
    private var category : AirlinesCategory?
    
    
    var AirlineDescription : String?{
        
        get{
            
            return self.AirlineDescription
            
        }
        
        set{
            
            self.AirlineDescription = newValue
            
        }
        
    }
    
    
    
    var AirlineType : String?{
        
        get{
            
            return self.AirlineType
            
        }
        
        set{
            
            self.AirlineType = newValue
            
        }
        
    }
    var Category : AirlinesCategory?{
        
        get{
            
            return self.category
            
        }
        set{
            
            self.category = newValue
            
        }
    }
    
    
    
    
    
    init(){
        
        self.AirlinesID = ""
        
        self.AirlineDescription = ""
        
        self.AirlineType = ""
        
        self.category = AirlinesCategory.None
    }
    
    
  
    
    
    init(AirlinesID: String,AirlinesDescription: String,AirlinesType: String,category: AirlinesCategory){
        self.AirlinesID = AirlinesID
        self.AirlinesDescription = AirlinesDescription
        self.AirlinesType = AirlinesType
        self.category = category
    }
    
    func displayData() -> String{
        var returnData = ""
        
        if self.AirlinesID != nil{
            returnData += "\n Airlines Id : " + self.AirlinesID!
        }
        
        if self.AirlinesDescription != nil{
            returnData += "\n Airlines Description : " + self.AirlinesDescription!
        }
        
        if self.AirlinesType != nil{
            returnData += "\n Airlines Type : " + self.AirlinesType!
        }
        
        if self.AirlinesType != nil{
            returnData += "\n Category : \(self.category ?? AirlinesCategory.None)"
        }
        
        return returnData
    }
    
    
  
    
    
    
  
    
   func registerUser(){
        
        print("Enter Airline Id : ")
        
        self.AirlinesID = readLine()!
        
        print("Enter Airline Description : ")
        
        self.AirlineDescription = readLine()!
        
        print("Enter Airline Type : ")
        
        self.AirlineType = readLine()!
        
    }
    
  
}
