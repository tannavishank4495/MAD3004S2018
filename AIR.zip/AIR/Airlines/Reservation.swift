//
//  Reservation.swift
//  Airlines
//
//  Created by Abhishek Bansal on 23/07/18.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Reservation: IDisplay{
    private var ReservationID : Int?
    private var ReservationPassengerID : String?
    private var ReservationDate : String?
    private var ReservationSeatNumber : String?
    private var ReservationMealType : String?
    var dataHelper = DataHelper()
    
    init(){
        self.ReservationID = 0
        self.ReservationPassengerID = ""
        self.ReservationDate = ""
        self.ReservationSeatNumber = ""
        self.ReservationMealType = ""
        
    }
    
    init(ReservationID:Int,  ReservationPassengerID: String, ReservationSeatNumber: String, ReservationMealType: String,ReservationDate:String){
        self.ReservationID = ReservationID
        self.ReservationPassengerID = ReservationPassengerID
        self.ReservationDate = ReservationDate
        self.ReservationSeatNumber = ReservationSeatNumber
        self.ReservationMealType = ReservationMealType
    }
    
   func delete()
   {
    self.ReservationID = nil
    self.ReservationPassengerID = nil
    self.ReservationDate = nil
    self.ReservationSeatNumber = nil
    self.ReservationMealType = nil
    
    }
   
    func reserveFlight(){
        
        dataHelper.displayAirlines()
        print("Please enter AirlineID from the List : " )
        let _ : String = readLine()!
        
        print("Please enter How many Tickets you want to reserve : " )
        let _ : String = readLine()!
        
        
        print("Enter Reservation ID: ")
        
        self.ReservationID = (Int)(readLine()!)!
        
        print("Enter Reservation Passenger ID : ")
        
        self.ReservationPassengerID = readLine()!
        
        
        print("Enter Reservation Date : ")
        
        self.ReservationDate  = readLine()!
        
        print("Enter Reservation Seat Number : ")
        
        self.ReservationSeatNumber  = readLine()!
        
        
        print("Enter Reservation Meal Type: ")
        
        self.ReservationMealType  = readLine()!
    
    
    
    print(" Flight Reserved ! " )
     let _ : String = readLine()!
        
        
    }
    

    
    
    func displayData() -> String{
        var returnData = ""
        
        
        
        if self.ReservationID != nil{
            
            returnData += "Reservation ID : \(String(describing: self.ReservationID))"
            
        }
        
       
        if self.ReservationPassengerID != nil{
            
            returnData += "\n Reservation PassengerID  " + self.ReservationPassengerID!
            
        }
        
       
        
        if self.ReservationDate  != nil{
            
            returnData += "\n Reservation Date : " + self.ReservationDate!
            
        }
        
        if self.ReservationSeatNumber  != nil{
            
            returnData += "\n Reservation SeatNumber : " + self.ReservationSeatNumber!
            
        }
        
       
        
        if self.ReservationMealType != nil{
            
            returnData += "\n Reservation MealType : " + self.ReservationMealType!
            
        }
        
        return returnData
        
    }
    
}


