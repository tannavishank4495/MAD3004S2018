//
//  main.swift
//  Airlines
//
//  Created by MacStudent on 19/07/18.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation




var formatter = DateFormatter()
DateFormatter.dateFormat(fromTemplate: "MM-dd-yyyy", options: 1, locale: Locale.current)
var dt = formatter.date(from: "August 12 2001")



print("\n----Hello, Welcome to the Airline reservation system !!----")


let dateCurrent = Date()

print("\n\nDate 1 : \(dateCurrent)")



let dateString = "12/01/2003"

let dateFormatter = DateFormatter()

dateFormatter.dateFormat = "MM/dd/yyyy"

let dateFromString = dateFormatter.date(from: dateString)

print("\nDate 2 : \(dateFromString!)\n\n")


var Vishank = Passenger()
Vishank.addPassenger()
print(Vishank.displayData())

var ASD = Employee()
ASD.addEmployee()
print(ASD.displayData())

var A = Reservation()
var choice = 1
var dataHelper = DataHelper()



while choice != 6{
    
    print("\t 1 : Browse Airlines ")
    print("\t 2 : Reserve Ticket ")
    print("\t 3 : Show Reservation ")
    print("\t 4 : Cancel Reservation ")
    print("\t 5 : Enquiry ")
    print("\t 6 : Exit ")
    print("-----------------------------------------")
    print("Enter you choice please : ")
    choice = (Int)(readLine()!)!

    switch choice{
    case 1:
        let B = Flight()
        //B.airlinesearchFrom()
        print(B.airlinesearchFrom())
        //B.airlinesearchTo()
        print(B.airlinesearchTo())
        dataHelper.displayAirlines()
    case 2:
        A.reserveFlight()
        print(A.displayData())

    case 3:
        print(A.displayData())

    case 4:
         print(A.delete())

    //case 5:
        //print(A.delete())

    case 6:
        exit(0)
    default:
        print("Please enter valid menu option.")
    }
}

