//
//  AirlinesEnquiry.swift
//  Airlines
//
//  Created by MacStudent on 23/07/18.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class AirlinesEnquiry{
     var EnquiryID : Int?
    private var EnquiryType : String?
    private var EnquiryTitle : String?
    private var EnquiryDescription : String?
    private var EnquiryDate : String?

    var enquiryType : String?{
        
        get{
            
            return self.EnquiryType
            
        }
        
        set{
            
            self.EnquiryType = newValue
            
        }
        
    }
    
    
    
    var enquiryTitle : String?{
        
        get{
            
            return self.EnquiryTitle
            
        }
        
        set{
            
            self.EnquiryTitle = newValue
            
        }
        
    }
    
    var enquiryDescription : String?{
        
        get{
            
            return self.EnquiryDescription
            
        }
        
        set{
            
            self.EnquiryDescription = newValue
            
        }
        
    }
    
    var enquiryDate : String?{
        
        get{
            
            return self.EnquiryDate
            
        }
        
        set{
            
            self.EnquiryDate = newValue
            
        }
        
    }
    
    
    init(){
        self.EnquiryID = 0
        self.EnquiryType = ""
        self.EnquiryTitle = ""
        self.EnquiryDescription = ""
        
            }
    
    init(EnquiryID: Int, EnquiryType: String, EnquiryTitle: String, EnquiryDescription: String, EnquiryDate: Date){
        self.EnquiryID = EnquiryID
        self.EnquiryType = EnquiryType
        self.EnquiryTitle = EnquiryTitle
        self.EnquiryDescription = EnquiryDescription
    }

  func addEnquiry()
  {
    
    }



}

