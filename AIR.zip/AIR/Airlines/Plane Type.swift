//
//  PlaneType.swift
//  Airlines
//
//  Created by Abhishek Bansal on 19/07/18.
//  Copyright © 2018 Abhishek Bansal. All rights reserved.
//

import Foundation

class PlaneType{
    var planeTypeID : String?
    var planeTypeTotalSeats : String?
    init(){
        self.planeTypeID = ""
        self.planeTypeTotalSeats = ""
        
    }
    init(planeTypeID: String){
        
        self.planeTypeID = planeTypeID
    }
    
    init(planeTypeTotalSeats: String){
        
        self.planeTypeTotalSeats = planeTypeTotalSeats
    }
    func displayData() -> String{
        var returnData = ""
        
        if self.planeTypeID != nil{
            returnData += "\n Plane Type Id : " + self.planeTypeID!
        }
        
        if self.planeTypeTotalSeats != nil{
            returnData += "\n Plane Type Total Seats : " + self.planeTypeTotalSeats!
        }
        
        return returnData
    }
    
}


