//
//  PlaneType.swift
//  Airlines
//
//  Created by MacStudent on 19/07/18.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class PlaneType{
    private var PlaneTypeID : String?
    private var PlaneTypeTotalSeats : String?
    private var PlaneTypeSeatMap : String?
    
    init(){
        self.PlaneTypeID = ""
        self.PlaneTypeTotalSeats = ""
        self.PlaneTypeSeatMap = ""
        
    }

    
    init(PlaneTypeID: String,PlaneTypeTotalSeats: String,PlaneTypeSeatMap: String){
        self.PlaneTypeTotalSeats = PlaneTypeTotalSeats
        self.PlaneTypeID = PlaneTypeID
        self.PlaneTypeSeatMap = PlaneTypeSeatMap
    }
    
    func displayData() -> String{
        var returnData = ""
        
        if self.PlaneTypeID != nil{
            returnData += "\n Plane Type Id : " + self.PlaneTypeID!
        }
        
        if self.PlaneTypeTotalSeats != nil{
            returnData += "\n Plane Type Total Seats : " + self.PlaneTypeTotalSeats!
        }
        
        if self.PlaneTypeSeatMap != nil{
            returnData += "\n Plane Type Seat Map : " + self.PlaneTypeSeatMap!
        }
        
        return returnData
    }
    
}
