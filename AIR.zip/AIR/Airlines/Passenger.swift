//
//  Passenger.swift
//  Airlines
//
//  Created by MacStudent on 23/07/18.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Passenger{
    private var PassengerID : String?
    private var PassengerPassportNumber : String?
    private var PassengerName : String?
    private var PassengerMobile : String?
    private var PassengerEmail : String?
    private var PassengerAddress : String?
    private var PassengerBirthDate : String?
    
    init(){
        self.PassengerID = ""
        self.PassengerPassportNumber = ""
        self.PassengerName = ""
        self.PassengerMobile = ""
        self.PassengerEmail = ""
        self.PassengerAddress = ""
        self.PassengerBirthDate = ""
        
    }
    init(PassengerID: String, PassengerPassportNumber: String, PassengerName: String, PassengerMobile: String, PassengerEmail: String, PassengerAddress: String){
        self.PassengerID = PassengerID
        self.PassengerPassportNumber = PassengerPassportNumber
        self.PassengerName = PassengerName
        self.PassengerMobile = PassengerMobile
        self.PassengerEmail = PassengerEmail
        self.PassengerAddress = PassengerAddress
        
    }
    
    
    
    func addPassenger()
    {
        print("Enter PassengerId : ")
        self.PassengerID = readLine()!
        print("Enter your PassportNumber : ")
        self.PassengerPassportNumber = readLine()!
        print("Enter your Name : ")
        self.PassengerName = readLine()
        print("Enter Address: ")
        self.PassengerAddress = readLine()!
        print("Enter email : ")
        self.PassengerEmail = readLine()!
        print("Enter your mobile number : ")
        self.PassengerMobile = readLine()!
        print("Enter date_of_birth : ")
        self.PassengerBirthDate = readLine()!
    }
    
    func displayData() -> String{
        var returnData = ""
        
        if self.PassengerID != nil{
            returnData += "\n Passenger Id:" +  self.PassengerID!
        }
        if self.PassengerPassportNumber != nil{
            returnData += "\n Passport Number:" +  self.PassengerPassportNumber!
        }
        if self.PassengerName != nil{
            returnData += "\n Passenger Name:" +  self.PassengerName!
        }
        if self.PassengerAddress != nil{
            returnData += "\n Address:" +  self.PassengerAddress!
        }
        if self.PassengerEmail != nil{
            returnData += "\n Email:" +  self.PassengerEmail!
        }
        if self.PassengerMobile != nil{
            returnData += "\n Mobile:" +  self.PassengerMobile!
        }
        if self.PassengerBirthDate != nil{
            returnData += "\n Date of birth:" +  self.PassengerBirthDate!
        }
        return returnData
    }

}
