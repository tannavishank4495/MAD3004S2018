//
//  Flight.swift
//  Airlines
//
//  Created by MacStudent on 23/07/18.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Flight{
    private var FlightId : String?
    private var FlightFrom : String?
    private var FlightTo : String?
    private var FlightScheduleDate :String?
    private var category : Airports?

    
    var flightID : String?{
        
        get{
            
            return self.FlightId
            
        }
        
        set{
            
            self.FlightId = newValue
            
        }
        
    }
    
    
    
    var flightFrom : String?{
        
        get{
            
            return self.FlightFrom
            
        }
        
        set{
            
            self.FlightFrom = newValue
            
        }
        
    }
    
    
    
    var flightTo : String?{
        
        get{
            
            return self.FlightTo
            
        }
        
        set{
            
            self.FlightTo = newValue
            
        }
        
    }
    
    
    
    var flightScheduleDate : String?{
        
        get{
            
            return self.FlightScheduleDate
            
        }
        
        set{
            
            self.FlightScheduleDate = newValue
            
        }
        
    }
    
    
    
    
    
   var Category : Airports?{
        
        get{
        
        return self.category
        
        }
        set{
        
        self.category = newValue
        
        }
        
        
        
    }
    
    init(){
        self.FlightId = ""
        self.FlightFrom = ""
        self.FlightTo = ""
        self.FlightScheduleDate = ""
        self.category = Airports.YYZ
    }
    
    init(FlightId: String, FlightFrom: String, FlightTo: String, FlightScheduleDate: String, FlightAirlineId: Int, FlightAirplaneId:String, FlightPilotId: String){
        self.FlightId = FlightId
        self.FlightFrom = FlightFrom
        self.FlightTo = FlightTo
        self.FlightScheduleDate = FlightScheduleDate
        self.category = Airports.YYZ
    }
    
    
   
    
    
    func registerUser(){
        
        print("Enter Flight Id : ")
        
        self.flightID = readLine()!
        
        print("Enter Flight From : ")
        
        self.flightFrom = readLine()!
        
        print("Enter Flight To : ")
        
        self.flightTo = readLine()!
        
        print("Enter Flight Schedule Date : ")
        
        self.flightScheduleDate = readLine()!
        
    
    }
    
    func airlinesearchFrom(){
        print("Please choose Flight From: ")
        for category in Airports.allCases{
            print("Enter \(category.rawValue) for  \(category)")
        }
        let choice = readLine()!
        self.category = Airports(rawValue: 1  )
        
        if (choice == "1")
        {
            print("YYZ : Toronto Pearson International Airport  selected")
            
        }else if (choice == "2")
        {
            
            print("DEL : Indra Gandhi International Airport selected")
            
        }
        else if (choice == "3"){
            
            print("HYD : Rajiv Gandhi Hyderabad International Airport selected" )
            
        }
        else if (choice == "4"){
            
            print("LHR : London Heathrow Airport selected")
        }
            
            else if (choice == "5"){
                
            print("UAE : United Arab Emirates selected")
    }
    }
    
    
    func airlinesearchTo(){
        print("Please choose Flight To: ")
        for category in Airports.allCases{
            print("Enter \(category.rawValue) for  \(category)")
        }
        let choice = readLine()!
        self.category = Airports(rawValue: 1  )
        
        if (choice == "1")
        {
            print("YYZ : Toronto Pearson International Airport  selected")
            
        }else if (choice == "2")
        {
            
            print("DEL : Indra Gandhi International Airport selected")
            
        }
        else if (choice == "3"){
            
            print("HYD : Rajiv Gandhi Hyderabad International Airport selected" )
            
        }
        else if (choice == "4"){
            
            print("LHR : London Heathrow Airport selected")
        }
            
        else if (choice == "5"){
            
            print("UAE : United Arab Emirates selected")
        }
    }
    
    
}
