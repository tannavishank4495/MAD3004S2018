//
//  Product.swift
//  Shopping
//
//  Created by MacStudent on 2018-07-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Product : IDDisplay{
    private var productID : Int?
    private var productName : String?
    private var unitPrice : Double?
    private var manufacturer : String?
    private var category : ProductCategory?
    
    var ProductID : Int? {
    get{return self.productID}
    set{self.productID = newValue}
    }
    var ProductName : String? {
        get{return self.productName}
        set{self.productName = newValue}
    }
    var UnitPrice : Double? {
        get{return self.unitPrice}
        set{self.unitPrice = newValue}
    }
    var Manufacturer : String? {
        get{return self.manufacturer}
        set{self.manufacturer = newValue}
    }
    var Category : ProductCategory? {
        get{return self.category}
        set{self.category = newValue}
    }
    
    init(){
        self.productID = 0
        self.productName = ""
        self.manufacturer = ""
        self.unitPrice = 0.0
        self.category = ProductCategory.None
        
    }
    init(productID: Int,productName: String,manufacturer: String,unitPrice: Double,category : ProductCategory){
        self.productID = productID
        self.productName = productName
        self.manufacturer = manufacturer
        self.unitPrice = unitPrice
        self.category = category
    }
    func displayData() -> String{
        var returnData = ""
        
        returnData += "\n Product ID : \(self.productID ?? 0)"
        returnData += "\n Product Name : \(self.productName ?? "")"
        returnData += "\n Manucfacturer : \(self.manufacturer ?? "")"
        returnData += "\n category : \(self.category ?? ProductCategory.None)"
        returnData += "\n Unit Price : \(self.unitPrice ?? 0.0)"
        return returnData
    }
    func newProdcut(){
        print("Enter Product ID : ")
        self.productID = (Int)(readLine()!)!
        print("Enter ProductName : ")
        self.productName = readLine()!
        print("Enter Manufacturer : ")
        self.manufacturer = readLine()!
        
        print("Please choose product category : ")
        for category in ProductCategory.allCases{
            print("\"Enter \(category.rawValue) for \(category)")
        }
        let choice = (Int)(readLine()!) ?? 5
        self.category = ProductCategory(rawValue: choice)
        
        print("Enter unit Price : ")
        self.unitPrice = Double(readLine()!)!
        
    }
}
