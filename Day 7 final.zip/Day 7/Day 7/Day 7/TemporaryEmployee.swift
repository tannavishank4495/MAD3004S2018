//
//  TemporaryEmployee.swift
//  Day 7
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class TempEmployee: Employee, INetPayCalculation{
    
    var hourHoliday: Int?
    
    var netPay: Double?{
        get{
            if self.hourHoliday! > 10 {
                return self.basicPay! - 100
            }else{
                return self.basicPay!
            }
        }
    }
       required init(empID: Int, empName: String, basicPay : Double, holiday : Int){
        self.hourHoliday = holiday
        super.init(empID: empID, empName: empName, basicPay: basicPay)
        
        }
    override func display() {
        super.display()
        print("Hours of holiday : \(self.hourHoliday ?? 0)")
        print("Net Pay: \(self.netPay?.asCurrency ?? self.basicPay?.asCurrency ?? 0.0.asCurrency)")
    }
    }


