//
//  PermanentEmployee.swift
//  Day 7
//
//  Created by MacStudent on 2018-07-21.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class PermanentEmployee : Employee{
    var vacationWeek : Int?
    
    //raed-only computed property
    var netPay : Double?{
        get{
        if self.vacationWeek! > 3{
            return self.basicPay! - 100
        }else{
            return self.basicPay!
        }
    }
}
    
    override init(){
        
        self.vacationWeek = 0
        super.init()
    }
    
    required init(empID: Int, empName: String, basicPay : Double, holiday : Int){
        self.vacationWeek = holiday
        super.init(empID: empID, empName: empName, basicPay: basicPay)
        
    }
    
    override func display(){
    super.display()
    print("vacation weeeks : \(self.vacationWeek ?? 0)")
        print("Net Pay: \(self.netPay?.asCurrency ?? self.basicPay?.asCurrency ?? 0.0.asCurrency)")
    }
}
