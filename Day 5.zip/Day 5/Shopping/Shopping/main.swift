//
//  main.swift
//  Shopping
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

var Santosh = Customer()
Santosh.customerID = "C101"
//Santosh.customerName = "Santosh"
print(Santosh.displayData())

var Param = Customer(customerID: "C102", customerName: "Paramjeet", address: "Brampton", email: "param@mad.com", creditCardInfo: "4520-0100-1234-5678", shippingInfo: "Ship to lambton college betweeen 08:00 AM - 12:00 PM")

print(Param.displayData())


var Saloni = Customer()
Saloni.registerUser()
print(Saloni.displayData())

Santosh.CustomerName = "Santosh"
Santosh.Email = "Santosh@mad.com"
Santosh.Address = "54 Marjary Ave. DownTown. Toronto"
Santosh.CreditCardInfo = "4520-0100-6543-8976"
Santosh.ShippingInfo = "Deliver at Papa John's at 03PM"
print(Santosh.displayData())
