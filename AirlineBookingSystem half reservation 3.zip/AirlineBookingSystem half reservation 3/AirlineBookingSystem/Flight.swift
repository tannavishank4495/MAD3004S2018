//
//  Flight.swift
//  AirlineBookingSystem
//
//  Created by MacStudent on 2018-07-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Flight{
    private var FlightId : String?
    private var FlightFrom : String?
    private var FlightTo : String?
    private var FlightScheduleDate :String?
    private var FlightAirlineId : Int?
    private var FlightAirplaneId : String?
    private var FlightPilotId : String?
    private var category : FlightCategory?
    
    
    var flightID : String?{
        
        get{
            
            return self.FlightId
            
        }
        
        set{
            
            self.FlightId = newValue
            
        }
        
    }
    
    
    
    var flightFrom : String?{
        
        get{
            
            return self.FlightFrom
            
        }
        
        set{
            
            self.FlightFrom = newValue
            
        }
        
    }
    
    
    
    var flightTo : String?{
        
        get{
            
            return self.FlightTo
            
        }
        
        set{
            
            self.FlightTo = newValue
            
        }
        
    }
    
    
    
    var flightScheduleDate : String?{
        
        get{
            
            return self.FlightScheduleDate
            
        }
        
        set{
            
            self.FlightScheduleDate = newValue
            
        }
        
    }
    
    
    
    var flightAirlineId : Int?{
        
        get{
            
            return self.FlightAirlineId
            
        }
        
        set{
            
            self.FlightAirlineId = newValue
            
        }
        
    }
    
    
    
    var flightAirplaneId : String?{
        
        get{
            
            return self.FlightAirplaneId
            
        }
        
        set{
            
            self.FlightAirplaneId = newValue
            
        }
        
    }
    
    
    
    var flightPilotId : String?{
        
        get{
            
            return self.FlightPilotId
            
        }
        
        set{
            
            self.FlightPilotId = newValue
            
        }
    }
    
    var Category : FlightCategory?{
        
        get{
            
            return self.category
            
        }
        set{
            
            self.category = newValue
            
        }
        
        
        
    }
    
    init(){
       //airlinesearch()
        self.FlightId = ""
        self.FlightFrom = ""
        self.FlightTo = ""
        self.FlightScheduleDate = ""
        self.FlightAirlineId = 0
        self.FlightAirplaneId = ""
        self.FlightPilotId = ""
        self.category = FlightCategory.None
    }
    
    init(FlightId: String, FlightFrom: String, FlightTo: String, FlightScheduleDate: String, FlightAirlineId: Int, FlightAirplaneId:String, FlightPilotId: String){
        //airlinesearch()
        self.FlightId = FlightId
        self.FlightFrom = FlightFrom
        self.FlightTo = FlightTo
        self.FlightScheduleDate = FlightScheduleDate
        self.FlightAirlineId = FlightAirlineId
        self.FlightAirplaneId = FlightAirplaneId
        self.FlightPilotId = FlightPilotId
        self.category = FlightCategory.None
    }
    
    
    
    
    
    func registerUser(){
        
        print("Enter Flight Id : ")
        
        self.flightID = readLine()!
        
        print("Enter Flight From : ")
        
        self.flightFrom = readLine()!
        
        print("Enter Flight To : ")
        
        self.flightTo = readLine()!
        
        print("Enter Flight Schedule Date : ")
        
        self.flightScheduleDate = readLine()!
        
        print("Enter Flight Airline Id : ")
        
        self.flightAirlineId = (Int)(readLine()!)!
        
        print("Enter Flight Airplane Id : ")
        
        self.flightAirplaneId = readLine()!
        
        print("Enter Flight Pilot Id : ")
        
        self.flightPilotId = readLine()!
        
    }
}

