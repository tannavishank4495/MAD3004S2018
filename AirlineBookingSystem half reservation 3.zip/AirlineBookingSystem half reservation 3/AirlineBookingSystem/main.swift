//
//  main.swift
//  AirlineBookingSystem
//
//  Created by MacStudent on 2018-07-27.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
import Foundation
var Vishank = Passenger()
Vishank.addPassenger()
print(Vishank.displayData())

var dataHelper = DataHelper()
dataHelper.displayAirline()

let dateCurrent = Date()
print("\nDate 1 : \(dateCurrent)")

let dateString = " 12/01/2003"
let dateFormatter = DateFormatter()
dateFormatter.dateFormat = "MM/dd/yyyy"
let dateFromString = dateFormatter.date(from: dateString)
print("\nDate 2 : \(dateFromString!)")



