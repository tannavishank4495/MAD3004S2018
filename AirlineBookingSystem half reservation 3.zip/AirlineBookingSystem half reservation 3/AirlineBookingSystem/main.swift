//
//  main.swift
//  AirlineBookingSystem
//
//  Created by MacStudent on 2018-07-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
var Vishank = Passenger()
Vishank.addPassenger()
print(Vishank.displayData())

var dataHelper = DataHelper()
dataHelper.displayProducts()

