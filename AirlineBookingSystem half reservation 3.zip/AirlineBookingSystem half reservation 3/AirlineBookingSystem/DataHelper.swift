//
//  DataHelper.swift
//  AirlineBookingSystem
//
//  Created by MacStudent on 2018-07-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class DataHelper{
    
    var AirlineList = [String : Airline]()
    
    
    
    init(){
        self.loadAirlineData()
        
    }
    
    
    
    func loadAirlineData(){
        
        AirlineList = [:]
        
        
        let AirCanada = Airline(airlineID: "A100", airlineDescription: "One of the best indian airline" , airlineType : "International" , airlineCategory : "international")
        
        AirlineList[AirCanada.airlineID!] = AirCanada
        
        let Ethihad = Airline(airlineID: "A101", airlineDescription: "First Canadian airline" , airlineType: "International" ,airlineCategory : "Domestic")
        
        AirlineList[Ethihad.airlineID!] = Ethihad
        
        let AirIndia = Airline(airlineID: "A102", airlineDescription: "Most preffeble airline" , airlineType: "International" , airlineCategory : "Economic")
        
        AirlineList[AirIndia.airlineID!] = AirIndia
        
        let BritishAirways = Airline(airlineID: "A103", airlineDescription: "Common airline" , airlineType: "International", airlineCategory : "Business" )
        
        AirlineList[BritishAirways.airlineID!] = BritishAirways
        
    }
    
    func displayAirline(){
        
        for (_, value) in self.AirlineList.sorted(by: { $0.key < $1.key} ){
            
            print(value.displayData())
            
        }
        
    }
    
}


