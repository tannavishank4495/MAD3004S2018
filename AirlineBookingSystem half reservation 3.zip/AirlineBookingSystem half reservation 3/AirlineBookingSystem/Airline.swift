//
//  Airline.swift
//  AirlineBookingSystem
//
//  Created by MacStudent on 2018-07-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Airline{
    var airlineID : String?
    private var airlineDescription : String?
    private var airlineCategory : String?
    private var airlineType : String?
    
    
     var AirlineDescription : String?{
        
        get{
            
            return self.airlineDescription
            
        }
        
        set{
            
            self.airlineDescription = newValue
            
        }
        
    }
    
    
    
    private var AirlineType : String?{
        
        get{
            
            return self.airlineType
            
        }
        
        set{
            
            self.airlineType = newValue
            
        }
        
    }
    var AirlineCategory : String?{
        
        get{
            
            return self.airlineCategory
            
        }
        set{
            
            self.airlineCategory = newValue
            
        }
    }
    
    
    
    
    
    init(){
        
        self.airlineID = ""
        
        self.airlineDescription = ""
        
        self.airlineType = ""
        
        self.airlineCategory = ""
    }
    
    
    
    
    
    init(airlineID: String,airlineDescription: String,airlineType: String,airlineCategory: String){
        self.airlineID = airlineID
        self.airlineDescription = airlineDescription
        self.airlineType = airlineType
        self.airlineCategory = airlineCategory
    }
    
    func displayData() -> String{
        var returnData = ""
        
        if self.airlineID != nil{
            returnData += "\n Airlines Id : " + self.airlineID!
        }
        
        if self.airlineDescription != nil{
            returnData += "\n Airline Description : " + self.airlineDescription!
        }
        
        if self.airlineType != nil{
            returnData += "\n Airline Type : " + self.airlineType!
        }
        
        if self.airlineCategory != nil{
            returnData += "\n AirlineCategory : " + self.airlineCategory!
            
        }
        
        return returnData
    }
    
    
    
    
    
    
    
    
    func registerUser(){
        
        print("Enter Airline Id : ")
        
        self.airlineID = readLine()!
        
        print("Enter Airline Description : ")
        
        self.airlineDescription = readLine()!
        
        print("Enter Airline Type : ")
        
        self.airlineType = readLine()!
        
    }
    
    
}
