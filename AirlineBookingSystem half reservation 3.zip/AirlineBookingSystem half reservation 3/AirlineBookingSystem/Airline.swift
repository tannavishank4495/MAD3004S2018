//
//  Airline.swift
//  AirlineBookingSystem
//
//  Created by MacStudent on 2018-07-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class Airline{
    
    private var airlineID : Int?
    
    private var airlineDescription : String?
    
    private var airlineType : String?
    
    var AirlineID : Int? {
        get{return self.airlineID}
        set{self.airlineID = newValue}
    }
    
    var AirlineDescription : String?{
        get{return self.airlineDescription}
        set{self.airlineDescription = newValue}
        }
    
    
    
    var AirlineType : String?{
        
        get{return self.AirlineType}
        set{self.AirlineType = newValue}
        
    }
    
    
    
    
    
    init(){
        
        self.airlineID = 0
        
        self.airlineDescription = ""
        
        self.airlineType = ""
        
    }
    
    
    
    init(airlineID: Int, airlineDescription: String, airlineType: String){
        
        
        
        self.airlineID = airlineID
        
        self.airlineDescription = airlineDescription
        
        self.airlineType = airlineType
        
    }
    
    
    
    func displayData() -> String{
        
        var returnData = ""
        
        
        
        if self.airlineID != nil{
            
            returnData += "Airline ID : \(String(describing: self.airlineID))"
            
        }
        
        if self.airlineDescription != nil{
            
            returnData += "\n Airline Description : " + self.airlineDescription!
            
        }
        
        if self.airlineType != nil{
            
            returnData += "\n Airline Type : " + self.airlineType!
            
        }
        
        return returnData
        
    }
    
    
    
    func registerUser(){
        
        print("Enter Airline Id : ")
        
        self.airlineID = (Int)(readLine()!)!
        
        print("Enter Airline Description : ")
        
        self.airlineDescription = readLine()!
        
        print("Enter Airline Type : ")
        
        self.airlineType = readLine()!
        
    }
    
}
