//
//  RequestLimitIncrease.swift
//  ErrorHandling
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class RequestLimitIncrease{
    var accountInfo = [
        "S1100" : requestFromAccount(type: "Saving",balance: 2312.43),
        "S1200" : requestFromAccount(type: "Saving",balance: 2312.43),
        "S1300" : requestFromAccount(type: "checkin",balance: 2312.43),
        "S1400" : requestFromAccount(type: "Saving",balance: 2312.43),
    ]
    func increaseLimit(accountNo: String) throws{
        guard let reqAcc = accountInfo[accountNo]
            else{
                throw limitIncreaseError.ineligible
                
        }
        guard reqAcc.type == "Saving" else{
            throw limitIncreaseError.noSavingAccount
        }
        guard reqAcc.balance >= 5000 else{
            throw limitIncreaseError.insufficientBalance(balanceNeeded: 50000 - reqAcc.balance)
        }
        print("Congratulations.. Your request is approved.")
    }
}
struct requestFromAccount{
    var type:String
    var balance: Double
}

enum limitIncreaseError: Error{
    case ineligible
    case noSavingAccount
    case insufficientBalance(balanceNeeded: Double)
}
